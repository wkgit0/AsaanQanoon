import os
import json

# Define the directory containing your JSON files
directory = r"C:\Users\DELL\Desktop\Shizra work\categories"

# Initialize an empty list to store all intents
all_intents = []

# Loop through all files in the directory
for filename in os.listdir(directory):
    if filename.endswith(".json"):
        file_path = os.path.join(directory, filename)
        try:
            with open(file_path) as f:
                data = json.load(f)
                all_intents.extend(data["intents"])
        except json.JSONDecodeError as e:
            print(f"Error in file: {file_path}")
            print(e)

# Save the merged data to a new JSON file
merged_data = {"intents": all_intents}
with open("intents.json", "w") as outfile:
    json.dump(merged_data, outfile, indent=4)

print("JSON files merged successfully!")
