import React, { useState } from "react";
import { Text, StyleSheet, View, ImageBackground, TouchableOpacity, Modal } from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { Video } from "expo-av";
import ContainerFrame from "../components/ContainerFrame";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles" ;

const SlashScreen = () => {
  const [videoVisible, setVideoVisible] = useState(false);
  const [showPopup, setShowPopup] = useState(true); // State to control showing the popup

  const handleUserDecision = (decision) => {
    setShowPopup(false); // Close the popup after user selects an option
    if (decision === "yes") {
      setVideoVisible(true); // Show the video modal
    } else {
      // Handle what should happen when user selects "No"
      // For now, we're just closing the modal and continuing
      setVideoVisible(false);
    }
  };
  return (
    <LinearGradient
      style={styles.slashScreen}
      locations={[0, 1]}
      colors={["rgba(58, 215, 250, 0.66)", "rgba(255, 255, 255, 0)"]}
    >
      <View style={[styles.frame, styles.framePosition3]}>
        <Text style={[styles.howMayI, styles.howTypo]}>{`HOW MAY 
I HELP YOU
TODAY?`}</Text>
      </View>
      <View style={[styles.frame1, styles.framePosition3]}>
        <View style={styles.frame2}>
          <View style={[styles.frame3, styles.framePosition2]}>
            <View style={styles.frame4}>
              <Image
                style={[styles.frameIcon, styles.framePosition1]}
                contentFit="cover"
                source={require("../assets/frame1.png")}
              />
              <View style={[styles.frame5, styles.framePosition1]}>
                <View style={[styles.frame6, styles.frame6Layout]}>
                  <View style={[styles.frame6, styles.frame6Layout]}>
                    <ImageBackground
                      style={[styles.workImg11, styles.workPosition]}
                      resizeMode="cover"
                      source={require("../assets/workimg11.png")}
                    />
                  </View>
                  <View style={[styles.frame8, styles.frameLayout1]}>
                    <Image
                      style={[styles.workImg21, styles.frameLayout1]}
                      contentFit="cover"
                      source={require("../assets/work-img-2-1.png")}
                    />
                  </View>
                </View>
                <View style={[styles.frame9, styles.frameLayout2]}>
                  <View style={styles.frame10}>
                    <View style={[styles.arrowRight, styles.wifiLayout]}>
                      <Text style={[styles.howMayI1, styles.howTypo]}>{`HOW MAY 
I HELP YOU
TODAY?`}</Text>
                    </View>
                  </View>
                  <View style={[styles.frame11, styles.frameLayout1]}>
                    <View style={[styles.frame11, styles.frameLayout1]}>
                      <Image
                        style={[styles.workImg21, styles.frameLayout1]}
                        contentFit="cover"
                        source={require("../assets/work-img-2-1.png")}
                      />
                    </View>
                    <View style={[styles.frame11, styles.frameLayout1]}>
                      <Image
                        style={[styles.workImg21, styles.frameLayout1]}
                        contentFit="cover"
                        source={require("../assets/work-img-2-1.png")}
                      />
                    </View>
                    <View style={[styles.frame11, styles.frameLayout1]}>
                      <Image
                        style={[styles.workImg21, styles.frameLayout1]}
                        contentFit="cover"
                        source={require("../assets/work-img-2-1.png")}
                      />
                    </View>
                    <View style={[styles.frame11, styles.frameLayout1]}>
                      <ImageBackground
                        style={[styles.workImg21, styles.frameLayout1]}
                        resizeMode="cover"
                        source={require("../assets/work-img-2-1.png")}
                      />
                    </View>
                  </View>
                 
                </View>
              </View>
            </View>
          </View>
       
        </View>
      {/* Add the Welcome Hand GIF */}
      <View style={styles.welcomeHandContainer}>
        <Image
          style={styles.welcomeHand}
          source={require("../assets/welcome.gif")}
        />
      </View>
        <ContainerFrame />
      </View>



      {/* Add Popup/Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={showPopup} // Show the popup based on state
        onRequestClose={() => {
          setShowPopup(false); // Close popup if user tries to close it
        }}
      >
        <View style={styles.modalView}>
          <Text style={styles.popupText}>Do you want user guidance?</Text>
          <TouchableOpacity
            style={styles.popupButton}
            onPress={() => handleUserDecision("yes")}
          >
            <Text style={styles.popupButtonText}>Yes</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.popupButton}
            onPress={() => handleUserDecision("no")}
          >
            <Text style={styles.popupButtonText}>No</Text>
          </TouchableOpacity>
        </View>
      </Modal>

      {/* Video Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={videoVisible}
        onRequestClose={() => {
          setVideoVisible(false);
        }}
      >
        <View style={styles.modalView}>
          <Video
            source={require("../assets/demo-video.mp4")}
            rate={1.0}
            volume={1.0}
            isMuted={false}
            resizeMode="cover"
            shouldPlay
            style={styles.video}
          />
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => setVideoVisible(false)}
          >
            <Text style={styles.closeButtonText}>Close</Text>
          </TouchableOpacity>
        </View>
      </Modal>

    </LinearGradient>
  );
};

const styles = StyleSheet.create({

  welcomeHandContainer: {
    position: "absolute",
    bottom: 40,
    right:20,
  },
  welcomeHand: {
    width: 100,
    height: 100,
  },
  framePosition3: {
    left: -106,
    position: "absolute",
    overflow: "hidden",
  },
  howTypo: {
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.interExtraBold,
    fontWeight: "800",
    fontSize: FontSize.size_6xl,
    position: "absolute",
  },
  framePosition2: {
    left: 0,
    top: 0,
    overflow: "hidden",
  },
  framePosition1: {
    left: 80,
    position: "absolute",
    overflow: "hidden",
  },
  frame6Layout: {
    height: 195,
    position: "absolute",
  },
  workPosition: {
    left: 24,
    top: 0,
  },
  frameLayout1: {
    height: 106,
    position: "absolute",
  },
  frameLayout2: {
    width: 191,
    left: 0,
    overflow: "hidden",
  },
  frameLayout: {
    width: 154,
    height: 25,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  howMayI: {
    left: 123,
    width: 204,
    top: 0,
    height: 94,
  },
  frame: {
    top: 391,
    width: 327,
    height: 94,
  },
  frameIcon: {
    top: 120,
    width: 86,
    height: 161,
  },
  workImg11: {
    borderRadius: 48,
    width: 180,
    height: 195,
    position: "absolute",
  },
  frame6: {
    left: 0,
    top: 0,
    overflow: "hidden",
    width: 204,
  },
  workImg21: {
    borderTopLeftRadius: Border.br_15xl,
    borderTopRightRadius: Border.br_17xl,
    borderBottomRightRadius: Border.br_11xl,
    borderBottomLeftRadius: Border.br_3xs,
    width: 172,
    left: 30,
    top: 0,
  },
  frame8: {
    width: 191,
    left: 0,
    overflow: "hidden",
    top: 9,
  },
  howMayI1: {
    top: 35,
    left: -187,
    width: 219,
    height: 69,
  },
  arrowRight: {
    left: 137,
  },
  frame10: {
    top: 174,
    width: 162,
    height: 25,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  frame11: {
    width: 191,
    left: 0,
    overflow: "hidden",
    top: 0,
  },
  frame17: {
    top: 0,
  },
  frame16: {
    top: 136,
  },
  frame9: {
    height: 199,
    top: 9,
    width: 191,
    position: "absolute",
  },
  frame5: {
    top: 293,
    height: 208,
    width: 204,
  },
  frame4: {
    left: 93,
    width: 284,
    height: 501,
    top: 0,
    position: "absolute",
    overflow: "hidden",
  },
  frame3: {
    width: 377,
    height: 501,
    position: "absolute",
  },
  frame2: {
    alignSelf: "stretch",
    height: 501,
    overflow: "hidden",
  },
  frame1: {
    top: -120,
    width: 441,
  },
  slashScreen: {
    flex: 1,
    width: "100%",
    height: 640,
    backgroundColor: "transparent",
    overflow: "hidden",
  },
  modalView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  popupText: {
    fontSize: 20,
    marginBottom: 20,
    color: "#fff",
  },
  popupButton: {
    backgroundColor: "#000",
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  popupButtonText: {
    fontSize: 16,
    color: "#fff",
  },

  video: {
    width: 300,
    height: 300,
  },
  closeButton: {
    marginTop: 20,
    padding: 10,
    backgroundColor: "#fff",
    borderRadius: 5,
  },
  closeButtonText: {
    fontSize: 16,
  },
});

export default SlashScreen;
