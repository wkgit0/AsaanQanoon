import React, { useState, useEffect } from "react";
import { View, StyleSheet, TextInput, FlatList, Text, BackHandler, Alert } from "react-native";
import { Button } from "react-native-paper";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { firebase } from '../config'; // Replace with the correct path to your firebase.js file

const ChatbotScreen = () => {
  const [inputText, setInputText] = useState("");
  const [suggestedSentences, setSuggestedSentences] = useState([]); // Suggested sentences
  const [chatHistory, setChatHistory] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const navigation = useNavigation();

  useEffect(() => {
    const backHandler = BackHandler.addEventListener("hardwareBackPress", () => {
      handleBackButtonPress();
      return true; // Prevent default behavior (closing the app)
    });

    return () => {
      backHandler.remove(); // Clean up the event listener
    };
  }, []);

  const handleBackButtonPress = () => {
    Alert.alert(
      "Exit",
      "Are you sure you want to quit the app?",
      [
        {
          text: "No",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel",
        },
        {
          text: "Yes",
          onPress: () => BackHandler.exitApp(),
        },
      ],
      { cancelable: false }
    );

    return true; // Avoid closing the app immediately
  };

  const handleTextInput = (text) => {
    setInputText(text);

    // Here, you can implement logic to suggest sentences based on the input text.
    // For this example, we use a hardcoded list of suggestions.
    const suggestions = [
      "What are the key sections covered in the Trade Union Act 1926?",
      "Can you provide information on the definitions outlined in the Trade Union Act 1926?",
      "Is there any information on penalties specified in the Trade Union Act 1926?",
      "When was the Trade Union Act 1926 originally enacted?",
      "What are the main sections of the Industrial Disputes Act 1947?",
      "How does the Industrial Disputes Act 1947 define terms like industry, industrial dispute, employer, and workman?",
      "What penalties are mentioned in the Industrial Disputes Act 1947?",
      "When was the Industrial Disputes Act 1947 enacted?",
      "What is the purpose of the Trade Union Act Amendment 1960?",
      "Can you provide information on the Industrial Employment Act 1946?",
      "What changes were made by the Industrial Relations Ordinance 2002 to the laws enacted in 1969?",
      "How does the Industrial Relations Act 2008 impact workers' rights?",
      "What is the current size of Pakistan's labor force?",
      "How long was Pakistan under British rule, and how did it influence early labor laws?",
      "What laws did Pakistan inherit from British India after gaining independence in 1947?",
      "What constitutional provisions guarantee the right to form labor associations in Pakistan?",
      "How does the Industrial Relations Act 2008 support the freedom of association for workers?",
      "What is the process for union registration in Pakistan?",
      "How are labor disputes resolved, and what role do strikes play in this process?",
      "How are employment contracts governed in Pakistan, and what is the role of the Standing Orders Ordinance 1968?",
      "What protections exist against discrimination and harassment in the workplace?",
      "Can you provide details on working hours, leave policies, and wage regulations?",
      "What is the current level of unionization in Pakistan's labor force?",
      "How does the government handle labor disputes, and what judicial bodies are involved?",
      "What are some of the challenges in enforcing labor laws in Pakistan?",
      "Who is the author of the content discussing labor laws in Pakistan?",
      "When was the Industrial Relations Act 2008 enacted, and what law did it replace?",
      "Where can one find references and sources for information on labor laws in Pakistan?",
    ];
    const filteredSuggestions = suggestions.filter((suggestion) =>
      suggestion.toLowerCase().includes(text.toLowerCase())
    );
    setSuggestedSentences(filteredSuggestions);
  };

  const handleSuggestionPress = (suggestion) => {
    setInputText(suggestion);
    setSuggestedSentences([]); // Clear suggestions
  };

  const handleSendMessage = async () => {
    if (inputText) {
      const userMessage = { text: inputText, user: true };
      setChatHistory([...chatHistory, userMessage]);
      setInputText("");
      setIsTyping(true);

      try {
        // Make a POST request to the Flask server
        const ngrokUrl = "https://76a9-35-237-245-228.ngrok-free.app";  // Replace with your actual ngrok URL
        const predictUrl = `${ngrokUrl}/predict`;

        const response = await fetch(predictUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ userInput: inputText }),
        });
        const userMessageRef = firebase.firestore().collection('chatHistory').doc(firebase.auth().currentUser.uid);
        await userMessageRef.collection('messages').add({
          text: inputText,
          user: true,
          timestamp: new Date(),
        });

        const data = await response.json();

        const botMessage = { text: data.response, user: false };
        setChatHistory((prevChat) => [...prevChat, botMessage]);
        await userMessageRef.collection('messages').add({
          text: data.response,
          user: false,
          timestamp: new Date(),
        });
      } catch (error) {
        console.error("Error sending message:", error);
      }

      setIsTyping(false);
    }
  };

  return (
    <LinearGradient
      style={styles.chatbotScreen}
      locations={[0, 1]}
      colors={["#3fbaff", "rgba(255, 255, 255, 0)"]}
    >
      <FlatList
        data={chatHistory}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={item.user ? styles.userMessage : styles.botMessage}>
            <Text>{item.text}</Text>
          </View>
        )}
        ListFooterComponent={isTyping && <Text style={styles.botMessage}>Typing...</Text>}
      />
      <TextInput
        style={styles.textInput}
        placeholder="Ask a question"
        value={inputText}
        onChangeText={handleTextInput}
        editable={!isTyping} // Disable TextInput while typing
      />
      {suggestedSentences.length > 0 && (
        <View style={styles.suggestionContainer}>
          {suggestedSentences.map((suggestion, index) => (
            <Text
              key={index}
              style={styles.suggestedSentence}
              onPress={() => handleSuggestionPress(suggestion)}
            >
              {suggestion}
            </Text>
          ))}
        </View>
      )}
      <Button
        style={styles.sendButton}
        mode="contained"
        onPress={handleSendMessage}
        disabled={isTyping} // Disable button while typing
      >
        Send
      </Button>
      <Button
        style={styles.historyButton}
        mode="contained"
        onPress={() => navigation.navigate("HistoryScreen")}
      >
        History
      </Button>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  chatbotScreen: {
    flex: 1,
    width: "100%",
    backgroundColor: "transparent",
    overflow: "hidden",
    paddingVertical: 80,
  },
  userMessage: {
    alignSelf: "flex-end",
    backgroundColor: "#3fbaff",
    borderRadius: 8,
    margin: 5,
    padding: 10,
  },
  botMessage: {
    alignSelf: "flex-start",
    backgroundColor: "#f2f2f2",
    borderRadius: 8,
    margin: 5,
    padding: 10,
  },
  textInput: {
    backgroundColor: "white",
    padding: 10,
    margin: 10,
    borderRadius: 8,
  },
  historyButton: {
    backgroundColor: "#3fbaff",
    marginLeft: 10,
    width: 340,
    marginBottom: -40,
    padding: 5,
    borderRadius: 8,
  },
  sendButton: {
    backgroundColor: "#3fbaff",
    margin: 10,
    padding: 5,
    borderRadius: 8,
  },
  suggestionContainer: {
    backgroundColor: "white",
    borderRadius: 8,
    margin: 10,
  },
  suggestedSentence: {
    padding: 10,
    borderBottomWidth: 1,
    borderColor: "#ccc",
  },
});

export default ChatbotScreen;
