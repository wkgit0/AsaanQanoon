import React, { createContext, useContext, useState, useCallback } from 'react';

const ChatContext = createContext();

export const ChatProvider = ({ children }) => {
  const [chatHistory, setChatHistory] = useState([]);

  const addMessageToChatHistory = useCallback((sender, message) => {
    const newMessage = { sender, text: message, timestamp: new Date() };
    setChatHistory((prevChatHistory) => [...prevChatHistory, newMessage]);
  }, []);

  return (
    <ChatContext.Provider value={{ chatHistory, addMessageToChatHistory }}>
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};
