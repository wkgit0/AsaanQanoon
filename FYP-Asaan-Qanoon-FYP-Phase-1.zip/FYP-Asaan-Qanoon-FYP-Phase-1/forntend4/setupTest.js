// setupTest.js
import 'react-native';
import { View } from 'react-native';

// Mock the Image component
jest.mock('react-native', () => {
  const { View: OriginalView } = jest.requireActual('react-native');
  const MockImage = jest.fn((props) => <OriginalView {...props} />);
  return {
    ...jest.requireActual('react-native'),
    Image: MockImage,
  };
});
