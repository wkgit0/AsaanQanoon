// App.test.js
import React from 'react';
import { render } from '@testing-library/react-native';
import '@testing-library/jest-native/extend-expect';
import App from './App';

// Mock the Firebase imports
jest.mock('firebase/compat/app', () => {
  return {
    apps: [],
    initializeApp: jest.fn(),
    // Add other Firebase methods used in your code
  };
});

jest.mock('firebase/compat/auth', () => ({
  // Mock the auth module
}));

jest.mock('firebase/compat/firestore', () => ({
  // Mock the firestore module
}));

describe('App', () => {
  test('renders without crashing', () => {
    render(<App />);
  });
});
