import * as React from "react";
import { View, Text } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import SlashScreen from "./screens/SlashScreen";
import SignupScreen from "./screens/SignupScreen";
import LOGINSCREEN from "./screens/LOGINSCREEN";
import ChatbotScreen from "./screens/ChatbotScreen";
import ForgotPasswordScreen from "./screens/ForgotPasswordScreen";
import HistoryScreen from "./screens/HistoryScreen";
import ResetPasswordScreen from "./screens/ResetPasswordScreen";
import { ChatProvider } from './ChatContext'; // Update the path accordingly




const Stack = createNativeStackNavigator();

const App = () => {
  const [showSlashScreen, setShowSlashScreen] = React.useState(true);

  const [fontsLoaded, error] = useFonts({
    "Inter-Regular": require("./assets/fonts/Inter-Regular.ttf"),
    "Inter-Medium": require("./assets/fonts/Inter-Medium.ttf"),
    "Inter-Bold": require("./assets/fonts/Inter-Bold.ttf"),
    "Inter-ExtraBold": require("./assets/fonts/Inter-ExtraBold.ttf"),
    "InriaSerif-Light": require("./assets/fonts/InriaSerif-Light.ttf"),
    "InriaSerif-Bold": require("./assets/fonts/InriaSerif-Bold.ttf"),
  });

  if (!fontsLoaded || error) {
    return null;
  }

  const handleGetStarted = () => {
    setShowSlashScreen(false);
  };

  return (
    <ChatProvider>
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          {showSlashScreen ? (
            <Stack.Screen name="SlashScreen" component={SlashScreen} />
          ) : (
            <Stack.Group>
              <Stack.Screen name="SignupScreen" component={SignupScreen} />
              <Stack.Screen name="LOGINSCREEN" component={LOGINSCREEN} />
              <Stack.Screen name="ChatbotScreen" component={ChatbotScreen} />
              <Stack.Screen
                name="ForgotPasswordScreen"
                component={ForgotPasswordScreen}
              />
              <Stack.Screen name="HistoryScreen" component={HistoryScreen} />
              <Stack.Screen
                name="ResetPasswordScreen"
                component={ResetPasswordScreen}
              />
            </Stack.Group>
          )}
        </Stack.Navigator>
        {showSlashScreen && (
          <View
            style={{
              position: 'absolute',
              bottom: 208,
              left: -60,
              right: 20,
            }}
          >
            <Text
              style={{ textAlign: 'center', fontSize: 20, color: 'transparent' }}
              onPress={handleGetStarted}
            >
              Get Started
            </Text>
          </View>
        )}
      </NavigationContainer>
    </ChatProvider>
  );
};

export default App;
