import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { Button } from "react-native-paper";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const FormContainer = () => {
  const handlePress = () => {
    // Add your button press logic here
  };

  return (
    <View style={[styles.frame, styles.framePosition]}>
      <View style={[styles.frame1, styles.framePosition]}>
        <Image
          style={[styles.frameIcon, styles.framePosition]}
          contentFit="cover"
          source={require("../assets/frame3.png")}
        />
        <View style={[styles.frame2, styles.frameLayout]}>
          <View style={[styles.frame3, styles.framePosition]}>
            <Text style={[styles.submit, styles.submitPosition]}>Submit</Text>
          </View>
          <View style={[styles.frame4, styles.frameLayout]}>
            <Button
              style={[styles.frameChild, styles.submitPosition]}
              mode="contained"
              contentStyle={styles.rectangleButtonBtn}
              onPress={handlePress} // Add the onPress event handler
            >
              Submit
            </Button>
          </View>
        </View>
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  rectangleButtonBtn: {
    borderRadius: 40,
    height: 46,
    width: 241,
  },
  framePosition: {
    overflow: "hidden",
    position: "absolute",
  },
  frameLayout: {
    height: 161,
    width: 241,
    overflow: "hidden",
    position: "absolute",
  },
  submitPosition: {
    position: "absolute",
    left: 0,
  },
  frameIcon: {
    left: 60,
    width: 166,
    height: 379,
    top: 0,
  },
  submit: {
    bottom: 127,
    fontSize: FontSize.size_lg,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorBlack,
    textAlign: "right",
    left: 0,
  },
  frame3: {
    top: 12,
    left: 89,
    width: 63,
    height: 149,
  },
  frameChild: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    left: 0,
    top: 0,
  },
  frame4: {
    left: 0,
    top: 0,
  },
  frame2: {
    top: 218,
    left: 152,
  },
  frame1: {
    top: 1,
    height: 264,
    width: 393,
    overflow: "hidden",
    left: 0,
  },
  frame: {
    height: 265,
    width: 393,
    overflow: "hidden",
    left: 0,
    top: 0,
  },
});

export default FormContainer;
