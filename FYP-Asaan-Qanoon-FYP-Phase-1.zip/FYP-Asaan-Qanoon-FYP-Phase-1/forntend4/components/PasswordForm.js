import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const PasswordForm = () => {
  return (
    <View style={styles.enterPassword}>
      
    </View>
  );
};

const styles = StyleSheet.create({
  enterPassword1: {
    fontSize: FontSize.size_xl,
    fontWeight: "300",
    fontFamily: FontFamily.inriaSerifLight,
    color: Color.colorBlack,
    textAlign: "left",
    height: 41,
    width: 282,
  },
  enterPassword: {
    position: "absolute",
    top: 390,
    left: 117,
    alignItems: "center",
    justifyContent: "center",
    width: 282,
  },
});

export default PasswordForm;
