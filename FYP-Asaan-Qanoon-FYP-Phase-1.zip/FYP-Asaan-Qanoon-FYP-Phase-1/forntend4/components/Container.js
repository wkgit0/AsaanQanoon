import * as React from "react";
import { View, StyleSheet } from "react-native";
import { Image } from "expo-image";
import { SafeAreaView } from "react-native-safe-area-context";
import { Color, Border } from "../GlobalStyles";

const Container = () => {
  return (
    <View style={[styles.frame, styles.frameLayout2]}>
      <View style={[styles.frame1, styles.frame1Position]}>
        <Image
          style={[styles.pngwing4Icon, styles.frame1Position]}
          contentFit="cover"
          source={require("../assets/pngwing-3.png")}
        />
      </View>
      <View style={[styles.frame2, styles.frameLayout1]}>
        <View style={[styles.frameChild, styles.frameLayout]} />
      </View>
      <View style={[styles.frame3, styles.frameLayout1]}>
        <SafeAreaView style={[styles.frameItem, styles.frameLayout]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameLayout2: {
    overflow: "hidden",
    width: 360,
  },
  frame1Position: {
    height: 50,
    left: 0,
    position: "absolute",
  },
  frameLayout1: {
    height: 33,
    overflow: "hidden",
    position: "absolute",
  },
  frameLayout: {
    width: 118,
    backgroundColor: Color.colorGainsboro,
    height: 33,
    top: 0,
    position: "absolute",
  },
  pngwing4Icon: {
    width: 49,
    top: 0,
  },
  frame1: {
    top: 33,
    overflow: "hidden",
    width: 360,
  },
  frameChild: {
    left: 214,
    borderRadius: Border.br_21xl,
  },
  frame2: {
    left: 14,
    width: 332,
    top: 0,
  },
  frameItem: {
    borderTopLeftRadius: Border.br_21xl,
    borderTopRightRadius: Border.br_21xl,
    borderBottomRightRadius: Border.br_21xl,
    left: 0,
  },
  frame3: {
    top: 42,
    left: 55,
    width: 250,
  },
  frame: {
    top: 314,
    height: 83,
    left: 0,
    position: "absolute",
    overflow: "hidden",
    width: 360,
  },
});

export default Container;
