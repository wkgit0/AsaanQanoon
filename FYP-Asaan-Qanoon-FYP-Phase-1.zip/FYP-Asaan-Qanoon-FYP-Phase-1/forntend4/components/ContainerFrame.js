import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { Button } from "react-native-paper";
import { Border, FontSize, FontFamily, Color } from "../GlobalStyles";

const ContainerFrame = () => {
  return (
    <View style={[styles.frame, styles.frameLayout]}>
      <View style={[styles.frame1, styles.frameLayout]}>
        <Image
          style={styles.frameChild}
          contentFit="cover"
          source={require("../assets/ellipse-3.png")}
        />
        <Button
          style={styles.frameItem}
          uppercase={true}
          mode="contained"
          contentStyle={[styles.rectangleButtonBtn, { backgroundColor: "#3498db" }]}
         
        />
        <Text style={styles.getStarted}>{`Get Started `}</Text>
        <Image
          style={styles.vectorIcon}
          contentFit="cover"
          source={require("../assets/vector2.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleButtonBtn: {
    height: 57,
    width: 292,
    borderTopRightRadius: 30, // Adjust the border radius to make it rounded
    borderBottomRightRadius: 30,
    
  },
  frameLayout: {
    height: 247,
    overflow: "hidden",
  },
  frameChild: {
    top: 26,
    left: 60,
    width: 128,
    height: 165,
    position: "absolute",
  },
  frameItem: {
    top: 192,
    left: 59,
    borderTopRightRadius: Border.br_31xl,
    borderBottomRightRadius: Border.br_31xl,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    position: "absolute",
  },
  getStarted: {
    bottom: 17,
    left: 153,
    fontSize: FontSize.size_lg,
    fontWeight: "800",
    fontFamily: FontFamily.interExtraBold,
    color: Color.colorBlack,
    textAlign: "right",
    position: "absolute",
    
  },
  vectorIcon: {
    height: "5.8%",
    width: "5.54%",
    top: "85.51%",
    right: "16.61%",
    bottom: "8.7%",
    left: "77.86%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  frame1: {
    top: 0,
    left: 46,
    width: 361,
    position: "absolute",
    overflow: "hidden",
  },
  frame: {
    alignSelf: "stretch",
    marginTop: -61,
    overflow: "hidden",
  },
});

export default ContainerFrame;
