import * as React from "react";
import { TextInput as RNPTextInput } from "react-native-paper";
import { StyleSheet, View } from "react-native";
import MailFormContainer from "./MailFormContainer";
import { Border } from "../GlobalStyles";

const Form = () => {
  return (
    <View style={[styles.frame, styles.framePosition1]}>
      <View style={styles.frame1}>
        <View style={styles.frame2}>
          <RNPTextInput
            style={[styles.frameChild, styles.frameLayout]}
            mode="outlined"
            theme={{ colors: { background: "#fff" } }}
          />
          <MailFormContainer
            emailInputText="confirm new password"
            propTop={6}
            propLeft={51}
          />
        </View>
      </View>
      <View style={[styles.frame3, styles.framePosition]}>
        <View style={[styles.frame3, styles.framePosition]}>
          <View style={[styles.frame5, styles.framePosition]}>
            <RNPTextInput
              style={[styles.frameItem, styles.frameLayout]}
              mode="outlined"
              theme={{ colors: { background: "#fff" } }}
            />
          </View>
          <View style={[styles.frame6, styles.framePosition1]}>
            <MailFormContainer
              emailInputText="enter new password"
              propTop={22}
              propLeft={0}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  framePosition1: {
    overflow: "hidden",
    position: "absolute",
    top: 0,
  },
  frameLayout: {
    borderRadius: Border.br_381xl,
    width: 302,
    height: 50,
    left: 0,
    position: "absolute",
  },
  framePosition: {
    height: 64,
    left: 0,
    overflow: "hidden",
    top: 0,
    position: "absolute",
  },
  frameChild: {
    width: 302,
    top: 0,
    borderRadius: Border.br_381xl,
  },
  frame2: {
    top: 95,
    height: 50,
    left: 0,
    width: 333,
    overflow: "hidden",
    position: "absolute",
  },
  frame1: {
    left: 3,
    width: 333,
    overflow: "hidden",
    height: 145,
    top: 0,
    position: "absolute",
  },
  frameItem: {
    top: 14,
    width: 302,
  },
  frame5: {
    width: 302,
  },
  frame6: {
    left: 54,
    width: 282,
    height: 63,
    overflow: "hidden",
    position: "absolute",
  },
  frame3: {
    width: 336,
    height: 64,
  },
  frame: {
    left: 118,
    height: 145,
    overflow: "hidden",
    width: 336,
    position: "absolute",
  },
});

export default Form;
