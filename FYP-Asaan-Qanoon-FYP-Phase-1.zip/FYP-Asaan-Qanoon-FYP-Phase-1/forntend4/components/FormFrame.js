import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, TextInput, View } from "react-native";
import { Button as RNEButton } from "@rneui/themed";
import { FontFamily, FontSize } from "../GlobalStyles";

const FormFrame = () => {
  return (
    <View style={[styles.frame, styles.frameLayout]}>
      <Image
        style={[styles.frameIcon, styles.frameIconPosition]}
        contentFit="cover"
        source={require("../assets/frame4.png")}
      />
      <View style={styles.frame1}>
        <TextInput
          style={[styles.askQuestion, styles.frameIconPosition]}
          placeholder="Ask Question?"
          placeholderTextColor="#fff"
        />
      </View>
      <View style={styles.frame2}>
        <RNEButton
          radius={5}
          iconPosition="left"
          type="solid"
          color="#fff"
          containerStyle={styles.vectorIcon1Btn}
          buttonStyle={styles.vectorIcon1Btn1}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  vectorIcon1Btn: {
    left: "90.36%",
    right: "-0.04%",
    top: "0%",
    bottom: "0%",
    position: "absolute",
  },
  vectorIcon1Btn1: {
    height: "100%",
    width: "9.67%",
    borderStyle: "solid",
  },
  frameLayout: {
    height: 59,
    width: 334,
    overflow: "hidden",
  },
  frameIconPosition: {
    left: 0,
    top: 0,
    position: "absolute",
  },
  frameIcon: {
    overflow: "hidden",
    height: 59,
    width: 334,
  },
  askQuestion: {
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_lg,
  },
  frame1: {
    top: 15,
    left: 32,
    width: 270,
    height: 22,
    overflow: "hidden",
    position: "absolute",
  },
  frame2: {
    top: 7,
    left: 39,
    width: 255,
    height: 25,
    overflow: "hidden",
    position: "absolute",
  },
  frame: {
    top: 466,
    left: 13,
    overflow: "hidden",
    position: "absolute",
  },
});

export default FormFrame;
