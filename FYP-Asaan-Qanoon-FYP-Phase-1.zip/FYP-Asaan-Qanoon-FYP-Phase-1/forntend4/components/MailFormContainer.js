import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const MailFormContainer = ({ emailInputText, propTop, propLeft }) => {
  const enterYourMailStyle = useMemo(() => {
    return {
      ...getStyleValue("top", propTop),
      ...getStyleValue("left", propLeft),
    };
  }, [propTop, propLeft]);

  return (
    <View style={[styles.enterYourMail, enterYourMailStyle]}>
     
    </View>
  );
};

const styles = StyleSheet.create({
  enterYourMail1: {
    fontSize: FontSize.size_xl,
    fontWeight: "300",
    fontFamily: FontFamily.inriaSerifLight,
    color: Color.colorBlack,
    textAlign: "left",
    height: 41,
    width: 282,
  },
  enterYourMail: {
    position: "absolute",
    top: 296,
    left: 112,
    alignItems: "center",
    justifyContent: "center",
    width: 282,
  },
});

export default MailFormContainer;
