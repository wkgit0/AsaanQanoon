import * as React from "react";
import { TouchableOpacity } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Image } from "expo-image";
import { StyleSheet, View, Text } from "react-native";
import { Button, TextInput as RNPTextInput } from "react-native-paper";
import MailFormContainer from "./MailFormContainer";
import { FontSize, FontFamily, Color, Padding } from "../GlobalStyles";
import { StackActions } from "@react-navigation/native"; // Import StackActions

const FormSubmitFrame = () => {
  const navigation = useNavigation();

  const handleResetPassword = () => {
    // Replace this with the actual email input value
    const email = "your_email@example.com";

    // Navigate to the ResetPasswordScreen and pass the email as a parameter
    navigation.dispatch(StackActions.replace("ResetPasswordScreen", { email }));
  };

  return (
    <View style={styles.frame}>
      <View style={[styles.frame1, styles.frameLayout]}>
        <View style={[styles.frame2, styles.framePosition2]}>
          <Image
            style={[styles.frameIcon, styles.framePosition2]}
            contentFit="cover"
            source={require("../assets/frame2.png")}
          />
          <View style={[styles.frame3, styles.framePosition1]}>
            <View style={[styles.frame4, styles.framePosition2]}>
              <Button
                style={styles.frameChild}
                mode="contained"
                contentStyle={styles.rectangleButtonBtn}
                onPress={handleResetPassword} 
              >
                SUBMIT
              </Button>
            </View>
            <RNPTextInput
              style={[styles.frame5, styles.framePosition1]}
              mode="outlined"
            
            />
          </View>
        </View>
        <View style={[styles.frame6, styles.framePosition]}>
          <View style={[styles.frame7, styles.framePosition]}>
            <Text style={styles.submit}></Text>
          </View>
          <View style={[styles.frame8, styles.framePosition2]}>
          
            <MailFormContainer
              emailInputText="enter your mail"
              propTop={22}
              propLeft={0}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleButtonBtn: {
    borderRadius: 40,
    height: 46,
    width: 241,
  },
  frameLayout: {
    width: 473,
    height: 180,
  },
  framePosition2: {
    top: 0,
    overflow: "hidden",
    position: "absolute",
  },
  framePosition1: {
    width: 355,
    top: 0,
    overflow: "hidden",
    position: "absolute",
  },
  framePosition: {
    height: 168,
    top: 0,
    overflow: "hidden",
    position: "absolute",
  },
  frameIcon: {
    left: 20,
    width: 424,
    height: 162,
  },
  frameChild: {
    top: 134,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    left: 0,
    position: "absolute",
  },
  frame4: {
    left: 10,
    width: 241,
    height: 180,
  },
  frame5: {
    height: 64,
    left: 0,
  },
  frame3: {
    left: 118,
    height: 180,
  },
  frame2: {
    left: -5,
    height: 180,
    width: 380,
  },
  submit: {
    bottom: 0,
    fontSize: FontSize.size_lg,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: "white",
    textAlign: "right",
    left: 0,
    position: "absolute",
  },
  frame7: {
    left: 65,
    width: 63,
  },
  frame8: {
    height: 63,
    width: 282,
    left: 10,
  },
  frame6: {
    left: 172,
    width: 282,
  },
  frame1: {
    height: 180,
    overflow: "hidden",
  },
  frame: {
    top: 318,
    left: -110,
    width: 519,
    alignItems: "flex-end",
    justifyContent: "center",
    paddingHorizontal: 0,
    paddingVertical: Padding.p_0,
    overflow: "hidden",
    position: "absolute",
  },
});

export default FormSubmitFrame;
