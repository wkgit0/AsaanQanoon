import React, { useMemo } from "react";
import { TextInput as RNPTextInput } from "react-native-paper";
import { StyleSheet, Text, View } from "react-native";
import { Border, FontSize, FontFamily, Color } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const CardForm = ({ passwordInput, propTop, propHeight, propTop1,secureTextEntry}) => {
  const frameStyle = useMemo(() => {
    return {
      ...getStyleValue("top", propTop),
      ...getStyleValue("height", propHeight),
    };
  }, [propTop, propHeight]);

  const enterYourNameStyle = useMemo(() => {
    return {
      ...getStyleValue("top", propTop1),
    };
  }, [propTop1]);

  return (
    <View style={[styles.frame, styles.framePosition, frameStyle]}>
      <RNPTextInput
        style={[styles.frameChild, styles.framePosition]}
        mode="outlined"
        theme={{ colors: { background: "#fff" } }}
        placeholder={` ${passwordInput}`}
        secureTextEntry={secureTextEntry}
      />
      <View style={[styles.enterYourName, enterYourNameStyle]}>
        
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  framePosition: {
    left: 0,
    position: "absolute",
  },
  frameChild: {
    top: 0,
    borderRadius: Border.br_381xl,
    width: 302,
    height: 50,
  },
  enterYourName1: {
    height: "100%",
    width: "100%",
    top: "0%",
    left: "0%",
    fontSize: FontSize.size_xl,
    fontWeight: "300",
    fontFamily: FontFamily.inriaSerifLight,
    color: Color.colorBlack,
    textAlign: "left",
    position: "absolute",
  },
  enterYourName: {
    top: 12,
    left: 39,
    width: 271,
    height: 42,
    position: "absolute",
  },
  frame: {
    top: 72,
    width: 310,
    height: 54,
    overflow: "hidden",
  },
});

export default CardForm;
