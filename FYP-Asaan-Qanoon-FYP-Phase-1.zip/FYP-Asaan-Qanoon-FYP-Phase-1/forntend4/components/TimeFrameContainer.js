import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const TimeFrameContainer = () => {
  return (
    <View style={styles.frame}>
      <Image
        style={[styles.signalIcon, styles.amPosition]}
        contentFit="cover"
        source={require("../assets/signal1.png")}
      />
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector.png")}
      />
      <Image
        style={[styles.vectorIcon1, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector1.png")}
      />
      <Text style={[styles.am, styles.amPosition]}>9:09 AM</Text>
      <Image
        style={styles.frameChild}
        contentFit="cover"
        source={require("../assets/ellipse-1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  amPosition: {
    top: 84,
    position: "absolute",
  },
  vectorIconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    bottom: "56.18%",
    overflow: "hidden",
    position: "absolute",
  },
  signalIcon: {
    left: 357,
    width: 24,
    height: 17,
    overflow: "hidden",
  },
  vectorIcon: {
    height: "6.07%",
    width: "4.54%",
    top: "37.74%",
    right: "7.03%",
    left: "88.44%",
  },
  vectorIcon1: {
    height: "4.34%",
    width: "4.99%",
    top: "39.48%",
    right: "0%",
    left: "95.01%",
  },
  am: {
    left: 123,
    fontSize: FontSize.size_sm,
    fontWeight: "800",
    fontFamily: FontFamily.interExtraBold,
    color: Color.colorBlack,
    textAlign: "left",
  },
  frameChild: {
    top: 66,
    left: 106,
    width: 91,
    height: 131,
    position: "absolute",
  },
  frame: {
    top: 54,
    left: 0,
    width: 441,
    height: 231,
    overflow: "hidden",
    position: "absolute",
  },
});

export default TimeFrameContainer;
