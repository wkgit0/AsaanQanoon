import React, { useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import * as Linking from 'expo-linking';

const RedirectScreen = () => {
  const navigation = useNavigation();

  useEffect(() => {
    // Handle the redirect here
    const url = Linking.makeUrl('redirect');
    // Extract necessary data from the URL and proceed with authentication
    // ...

    // Navigate back to the login screen or the desired screen
    navigation.goBack();
  }, []);

  return null;
};

export default RedirectScreen;
