// test-setup.js
import '@firebase/auth';
import '@firebase/firestore';
import '@firebase/app-compat';
import { FirebaseApp } from '@firebase/app-compat';

jest.mock('@firebase/app-compat', () => {
  return {
    __esModule: true,
    ...jest.requireActual('@firebase/app-compat'),
    initializeApp: jest.fn(),
    FirebaseApp,
  };
});
