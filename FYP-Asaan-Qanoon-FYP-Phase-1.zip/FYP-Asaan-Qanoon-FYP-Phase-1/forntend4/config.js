import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';

const firebaseConfig = {
    apiKey: "AIzaSyCj31SgZyJ5wJG1HCwOU4serlSCZ_zcHy4",
    authDomain: "fyp-asaan-qanoon.firebaseapp.com",
    projectId: "fyp-asaan-qanoon",
    storageBucket: "fyp-asaan-qanoon.appspot.com",
    messagingSenderId: "122864410921",
    appId: "1:122864410921:web:3c4e72538454e9aed29738"
  };

if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

export { firebase };