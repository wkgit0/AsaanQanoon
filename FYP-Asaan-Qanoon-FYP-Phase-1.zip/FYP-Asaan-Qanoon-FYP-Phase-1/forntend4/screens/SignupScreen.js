import React, { useState, useRef, useEffect } from 'react';
import { Button, TextInput as RNPTextInput } from "react-native-paper";
import { Ionicons } from '@expo/vector-icons';
import { Animated, Easing } from "react-native";
import { StyleSheet, Text, View, ImageBackground, TouchableOpacity, Alert } from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";
import { useNavigation } from '@react-navigation/native';
import { firebase } from '../config';
import { Audio } from 'expo-av';

const SignupScreen = () => {
  const navigation = useNavigation();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const flipValue = useRef(new Animated.Value(0)).current;
  const counter = useRef(0);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  const startFlipAnimation = () => {
    Animated.sequence([
      Animated.timing(flipValue, {
        toValue: 1,
        duration: 500,
        easing: Easing.linear,
        useNativeDriver: true,
      }),
      Animated.timing(flipValue, {
        toValue: 0,
        duration: 1000,
        easing: Easing.linear,
        useNativeDriver: true,
      }),
      Animated.delay(2000),
    ]).start(({ finished }) => {
      counter.current += 1;
      if (counter.current < 3) {
        startFlipAnimation();
      }
    });
  };

  useEffect(() => {
    startFlipAnimation();
  }, []);

  const rotateY = flipValue.interpolate({
    inputRange: [0, 1],
    outputRange: ["0deg", "180deg"],
  });

  const playSound = async (soundFile) => {
    console.log('Attempting to play sound:', soundFile);
    try {
      let soundObject;
      switch (soundFile) {
        case 'RegisterSound':
          soundObject = new Audio.Sound();
          await soundObject.loadAsync(require('../assets/RegisterSound.mp3'));
          break;
        case 'alertsound':
          soundObject = new Audio.Sound();
          await soundObject.loadAsync(require('../assets/alertsound.mp3'));
          break;
        default:
          throw new Error('Unknown sound file');
      }
      await soundObject.playAsync();
      console.log('Sound played successfully');
    } catch (error) {
      console.error('Failed to play sound', error);
    }
  };
  const handleRegisterClick = async () => {
    try {
      if (!validateEmail(email)) {
        Alert.alert('Invalid Email', 'Please enter a valid email address.');
        await playSound('alertsound');
        return;
      }
  
      if (password.length < 6) {
        Alert.alert('Weak Password', 'Password must be at least 6 characters long.');
        await playSound('alertsound');
        return;
      }
  
      const userCredential = await firebase.auth().createUserWithEmailAndPassword(email, password);
      const user = userCredential.user;

      // Play success sound
      await playSound('RegisterSound');
      
      navigation.navigate('LOGINSCREEN');
    } catch (error) {
      console.error('Error registering user:', error.message);
      // Play error sound
      await playSound('alertsound');
    }
  };

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleLoginClick = () => {
    navigation.navigate('LOGINSCREEN');
  };
    
  return (
    <LinearGradient
      style={styles.signupScreen}
      locations={[0, 1]}
      colors={["rgba(58, 215, 250, 0.66)", "rgba(255, 255, 255, 0)"]}
    >
      <View style={[styles.frame, styles.frameLayout3]}>
        <View style={[styles.frame1, styles.frameChildPosition]}>
          <TouchableOpacity onPress={handleLoginClick}>
            <Text style={styles.alreadyHaveAccount}>Already have an account? Login</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleRegisterClick}>
            <View style={[styles.frameChild, styles.frameChildPosition]}>
              <Button
                style={styles.rectangleButtonBtn}
                uppercase={true}
                mode="contained"
                contentStyle={styles.rectangleButtonBtn}
              >
                Register
              </Button>
            </View>
          </TouchableOpacity>
        </View>
      </View>
      <View style={[styles.frame2, styles.frameFlexBox]}>
        <View style={[styles.frame3, styles.frameFlexBox]}>
          <View style={[styles.frame4, styles.frameLayout1]}>
            <View style={[styles.frame5, styles.frameLayout1]}>

              <Image
                style={[styles.frameItem, styles.framePosition]}
                contentFit="cover"
                source={require("../assets/ellipse-1.png")}
              />
              <Image
                style={[styles.frameInner, styles.framePosition]}
                contentFit="cover"
                source={require("../assets/ellipse-2.png")}
              />
              <Text style={[styles.welcomeOnboard, styles.amFlexBox]}>
                welcome onboard !!
              </Text>
              <Animated.Image
                style={[
                  styles.workImg26,
                  { transform: [{  rotateY  }] },
                ]}
                resizeMode="cover"
                source={require("../assets/workimg26.png")}
              />           
              <RNPTextInput
                style={[styles.rectangleRnptextinput, styles.frameChild1Layout]}
                mode="outlined"
                theme={{ colors: { background: "#fff" } }}
                placeholder="Enter your name"
                value={username}
                onChangeText={setUsername}
              />
            </View>
            <View style={[styles.enterYourName, styles.enterLayout]}>

            </View>
          </View>
          <View style={[styles.frame6, styles.frameLayout]}>
            <RNPTextInput
              style={[styles.frameChild1, styles.inputStyle]}
              mode="outlined"
              theme={{ colors: { background: "#fff" } }}
              placeholder="Enter your email"
              value={email}
              onChangeText={setEmail}
            />
            <View style={[styles.enterYourName2, styles.enterLayout]}>
              
            </View>
          </View>
          <View style={[styles.frame6, styles.frameLayout]}>
            <RNPTextInput
              style={[styles.frameChild1, styles.inputStyle]}
              mode="outlined"
              theme={{ colors: { background: "#fff" } }}
              placeholder="Enter your password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
              right={
                <RNPTextInput.Icon
                  name={showPassword ? 'eye-off' : 'eye'}
                  onPress={togglePasswordVisibility}
                  />
        }
      />

            <View style={[styles.enterYourName2, styles.enterLayout]}>
              
            </View>
          </View>
          <View style={[styles.frame6, styles.frameLayout]}>
            <RNPTextInput
                    style={[styles.frameChild1, styles.inputStyle]}
                    mode="outlined"
                    theme={{ colors: { background: "#fff" } }}
                    placeholder="Confirm Password"
                    value={confirmPassword}
                    onChangeText={setConfirmPassword}
                    secureTextEntry={!showConfirmPassword}
                    right={
                      <RNPTextInput.Icon
                        name={showConfirmPassword ? 'eye-off' : 'eye'}
                        onPress={toggleConfirmPasswordVisibility}
                      />
                    }
                  />

            <View style={[styles.enterYourName2, styles.enterLayout]}>
            </View>
          </View>
        </View>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  alreadyHaveAccount: {
    marginTop: -2,
    textAlign: "left",
    marginBottom: 16,
    marginLeft:16,
    color: Color.colorDarkturquoise_100,
    fontFamily: FontFamily.inriaSerifBold,
    fontWeight: "700",
  
  },
   container: {
    flex: 1,
    // Other styles for your container
  },
  rectangleButtonBtn: {
    borderRadius: 40,
    height: 51,
    width: 241,
    backgroundColor: "#3498db",
  },
  frameLayout3: {
    height: 91,
    position: "absolute",
    overflow: "hidden",
    
  },
  frameChildPosition: {
    left: 0,
    top: 0,
  },
  frameFlexBox: {
    alignItems: "flex-end",
    overflow: "hidden",
  },
  frameLayout1: {
    height: 380,
    overflow: "hidden",
  },

  framePosition: {
    top: 120,
    position: "absolute",
  },
  frameChild1Layout: {      //enter name layout
    width: 302,
    height: 52,
    position: "absolute",
  },
  enterLayout: {
    height: 42,
    width: 271,
    position: "absolute",
  },
  frameLayout: {             
    width: 310,
    overflow: "hidden",
    
  },
  frameChild: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    position: "absolute",
  },
  register: {
    bottom: 9,
    left: 56,
    fontSize: FontSize.size_lg,
    textAlign: "right",
    width: 103,
    height: 30,
    color: Color.colorBlack,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    position: "absolute",
  },
  frame1: {
    width: 241,
    height: 100,
    position: "absolute",
    overflow: "hidden",
  },
  frame: {
    top: 552,
    left: 57,
    width: 275,
  },
  
  frameItem: {
    left: 106,
    width: 91,
    height: 131,
  },
  frameInner: {
    left: 122,
    width: 162,
    height: 74,
  },
  welcomeOnboard: {
    top: 270,
    fontSize: FontSize.size_6xl,
    width: 258,
    height: 41,
    left: 167,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    textAlign: "left",
  },
  workImg26: {
    top: 176,
    left: 213,
    borderTopLeftRadius: Border.br_15xl,
    borderTopRightRadius: Border.br_17xl,
    borderBottomRightRadius: Border.br_11xl,
    borderBottomLeftRadius: Border.br_3xs,
    width: 144,
    height: 85,
    position: "absolute",
  },
  rectangleRnptextinput: {
    top: 320,
    left: 128,
    backgroundColor: Color.colorWhite,
    height: 50,
  },
  frame5: {
    width: 438,
    position: "absolute",
    left: 0,
    top: 0,
  },
  enterYourName1: {
    height: "100%",
    top: "0%",
    left: "0%",
    fontSize: FontSize.size_xl,
    fontWeight: "300",
    fontFamily: FontFamily.inriaSerifLight,
    width: "100%",
  },
  enterYourName: {
    top: 328,
    left: 167,
  },
  frame4: {
    alignSelf: "stretch",
  },
  frameChild1: {
    height: 50,
    left: 0,
    top: 0,
  },
  enterYourName2: {
    top: 8,
    left: 39,
  },
  frame6: {                 //working
    marginTop: 21,
    height: 58,
  },
  frame3: {
    alignSelf: "stretch",
  },
  frame7: {
    height: 130,
    marginTop: 22,
    
  },
  frame2: {
    top: -120,
    left: -106,
    width: 438,
    position: "absolute",
  },
  signupScreen: {
    flex: 1,
    height: 709,
    backgroundColor: "transparent",
    overflow: "hidden",
    width: "100%",
  },
  inputStyle: {
    width: 302,
    borderRadius: Border.br_381xl,
    height: 50,
    position: "absolute",
  },
});

export default SignupScreen;
