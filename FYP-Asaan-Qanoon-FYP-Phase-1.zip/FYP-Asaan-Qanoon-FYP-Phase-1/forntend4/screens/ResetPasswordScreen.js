import React, { useState } from 'react';
import { Text, StyleSheet, View, ImageBackground , TouchableOpacity} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Color, FontSize, FontFamily,Border } from '../GlobalStyles';
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import FormContainer from "../components/FormContainer";
import Form from "../components/Form";

const ResetPasswordScreen = ({ route }) => {
  const { email, generatedOtp, timestamp } = route.params;
  const [enteredOtp, setEnteredOtp] = useState('');

  const handleVerifyOtp = () => {
    const currentTimestamp = new Date().getTime();
    const timeDifference = currentTimestamp - timestamp;

    if (enteredOtp === generatedOtp && timeDifference <= 15 * 60 * 1000) {
      // Otp is correct, and timestamp is within the acceptable time frame
      // You can add additional logic here, such as setting a state to allow password reset
    } else {
      // Incorrect OTP or link has expired, display an error message to the user
      console.error('Incorrect OTP or link has expired.');
    }
  };

  return (
    <LinearGradient
      style={styles.resetPasswordScreen}
      locations={[0, 1]}
      colors={["rgba(58, 215, 250, 0.66)", "rgba(255, 255, 255, 0)"]}
    >
      <View style={styles.frame}>
        <Text style={styles.enter4Digit}>
          Enter 4 Digit Code Send To Your Email
        </Text>
      </View>
      <View style={styles.frame1}>

      
        <Image
          style={[styles.frameChild, styles.framePosition]}
          contentFit="cover"
          source={require("../assets/ellipse-1.png")}
        />
        <Image
          style={[styles.frameItem, styles.framePosition]}
          contentFit="cover"
          source={require("../assets/ellipse-2.png")}
        />
        <ImageBackground
          style={styles.resetImg1}
          resizeMode="cover"
          source={require("../assets/resetimg1.png")}
        />
        <Text style={[styles.text, styles.amClr]}>- - - -</Text>
      </View>
      <View style={[styles.frame2, styles.frameLayout]}>
        <View style={[styles.frame3, styles.frameLayout]}>
          <FormContainer />
          <Form />
        </View>
      </View>
      <TouchableOpacity style={styles.ellipseButton} onPress={handleVerifyOtp}>
        <Text style={styles.buttonText}>Verify OTP</Text>
      </TouchableOpacity>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({

  amClr: {
    color: Color.colorBlack,
    textAlign: "left",
    position: "absolute",
  },
  framePosition: {
    top: 120,
    position: "absolute",
  },
  frameLayout: {
    height: 265,
    position: "absolute",
    overflow: "hidden",
  },
  enter4Digit: {
    left: 125,
    fontSize: FontSize.size_lg,
    color: Color.colorGray_100,
    width: 355,
    textAlign: "left",
    fontFamily: FontFamily.interMedium,
    fontWeight: "500",
    top: 0,
    height: 41,
    position: "absolute",
  },
  frame: {
    top: 265,
    width: 520,
    height: 41,
    left: -106,
    position: "absolute",
    overflow: "hidden",
  },
 
  frameChild: {
    left: 100,
    width: 91,
    height: 131,
  },
  frameItem: {
    left: 100,
    width: 162,
    height: 74,
  },
  resetImg1: {
    top: 200,
    left: 220,
    borderRadius: 103,
    width: 124,
    height: 113,
    position: "absolute",
  },
  text: {
    top: 314,
    left: 220,
    fontSize: 50,
    width: 210,
    height: 56,
    transform: [
      {
        rotate: "0.72deg",
      },
    ],
    fontFamily: FontFamily.interMedium,
    fontWeight: "500",
    color: Color.colorBlack,
  },
  frame1: {
    top: -120,
    width: 519,
    height: 373,
    left: -106,
    position: "absolute",
    overflow: "hidden",
  },
  frame3: {
    left: 10,
    width: 454,
    top: 0,
    height: 265,
  },
  frame2: {
    top: 318,
    width: 500,
    left: -106,
  },
  resetPasswordScreen: {
    flex: 1,
    width: "100%",
    height: 715,
    backgroundColor: "transparent",
    overflow: "hidden",
  },
});

export default ResetPasswordScreen;