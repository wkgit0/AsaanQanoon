import React, { useState,useRef, useEffect } from "react";
import { useNavigation } from "@react-navigation/native";
import { Image } from "expo-image";
import { Ionicons } from '@expo/vector-icons'; // Assuming you have Ionicons installed

import { StyleSheet, View, Text, ImageBackground, TouchableOpacity, Animated, Easing } from "react-native";
import { TextInput as RNPTextInput, Button } from "react-native-paper";
import { LinearGradient } from "expo-linear-gradient";
import PasswordForm from "../components/PasswordForm";
import MailFormContainer from "../components/MailFormContainer";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";
import { Alert } from 'react-native';
import { firebase } from '../config'; // Replace with the correct path to your firebase.js file



const LOGINSCREEN = () => {
  const navigation = useNavigation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const flipValue = useRef(new Animated.Value(0)).current;
  const counter = useRef(0);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };
  const startFlipAnimation = () => {
    Animated.sequence([
      Animated.timing(flipValue, {
        toValue: 1,
        duration: 500, // Duration for flipping to back
        easing: Easing.linear,
        useNativeDriver: true,
      }),
      Animated.timing(flipValue, {
        toValue: 0,
        duration: 1000, // Duration for flipping to front
        easing: Easing.linear,
        useNativeDriver: true,
      }),
      Animated.delay(2000), // Pause for 1 second between flips
    ]).start(({ finished }) => {
      // Increment the counter after each animation cycle
      counter.current += 1;

      // Check if the counter has reached 3, stop the animation
      if (counter.current < 3) {
        startFlipAnimation();
      }
    });
  };

  useEffect(() => {
    startFlipAnimation();
  }, []);

  const rotateY = flipValue.interpolate({
    inputRange: [0, 1],
    outputRange: ["0deg", "180deg"],
  });
  
  const handleLogin = async () => {
    try {
      // Sign in with Firebase Authentication
      await firebase.auth().signInWithEmailAndPassword(email, password);

      // After successful login, navigate to the desired screen (e.g., "ChatbotScreen")
      navigation.navigate('ChatbotScreen');
    } catch (error) {
      console.error('Error logging in:', error.message);

      if (error.code === 'auth/user-not-found') {
        Alert.alert('User Not Found', 'This email is not registered. Please sign up.');
      } else if (error.code === 'auth/wrong-password') {
        Alert.alert('Incorrect Password', 'Please enter the correct password.');
      } else {
        Alert.alert('Login Error', 'An error occurred during login. Please try again.');
      }
    }
  };

  const handleForgotPassword = () => {
    // Check if email is valid (you can add your validation logic)
    if (email) {
      navigation.navigate("ForgotPasswordScreen", { email });
    } else {
      // Handle invalid email (show an error message, for example)
    }
  };

  const handleSignup = () => {
    navigation.navigate("SignupScreen");
};
 

  return (
    <LinearGradient
      style={styles.loginScreen}
      locations={[0, 1]}
      colors={["rgba(58, 215, 250, 0.66)", "rgba(255, 255, 255, 0)"]}
    >
      <Image
        style={[styles.loginScreenChild, styles.loginPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Image
        style={styles.loginScreenItem}
        contentFit="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <Image
        style={[styles.loginScreenInner, styles.loginPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-31.png")}
      />
      <Animated.Image
        style={[
          styles.pngwing5Icon,
          { transform: [{ rotateY }] },
        ]}
        resizeMode="cover"
        source={require("../assets/pngwing5.png")}
      />
      <Text style={styles.welcomeBack}> Welcome back!!</Text>
      <RNPTextInput
        style={[styles.rectangleRnptextinput, styles.loginScreenChild1Layout]}
        mode="outlined"
        theme={{ colors: { background: "#fff" } }}
        placeholder="Enter Your mail"
        value={email}
        onChangeText={(text) => setEmail(text)}
      />
      <RNPTextInput
        style={[styles.loginScreenChild1, styles.loginScreenChild1Layout]}
        mode="outlined"
        theme={{ colors: { background: "#fff" } }}
        placeholder="Enter Password"
  
        value={password}
        onChangeText={(text) => setPassword(text)}
        secureTextEntry={!showPassword}
        right={
          <RNPTextInput.Icon
            name={showPassword ? 'eye-off' : 'eye'}
            onPress={togglePasswordVisibility}
            />
  }
/>
      <PasswordForm />

      {/* Forgot Password Button */}
      <View style={[styles.buttonContainer, { top: 612 }]}>
        <TouchableOpacity
          style={styles.ellipseButton}
          onPress={handleForgotPassword}
        >
          <Text style={styles.buttonText}>Forgot password</Text>
        </TouchableOpacity>
      </View>

      {/* Login Button */}
      <View style={[styles.buttonContainer, { top: 490 }]}>
        <TouchableOpacity
          style={styles.ellipseButton}
          onPress={handleLogin}
        > 
        
          <Text style={styles.buttonText}>Login</Text>
        </TouchableOpacity>
      </View>

      {/* Login with Gmail Button */}
      <View style={[styles.buttonContainer,{top:550}]}>
        <TouchableOpacity
          style={styles.ellipseButton}
          onPress={() => {
            // Add your code to handle the "Login with Gmail" action here
          }}
            // Add your code to handle the "Login with Gmail" action here
        
        >
          <Text style={styles.buttonText}>Login with Gmail</Text>
        </TouchableOpacity>
      </View>

      <MailFormContainer emailInputText="enter your mail" />

      <Text style={[styles.dontHaveAnContainer,{top:680}]}>
        <Text style={styles.dontHaveAn}>Don’t have an account?</Text>
        <Text style={styles.signup}>
          <Text style={styles.text}>{` `}</Text>
        <TouchableOpacity onPress={handleSignup}>
          <Text style={styles.signup}>Signup</Text>
        </TouchableOpacity>
        </Text>
      </Text>
    </LinearGradient>

  );
};

const styles = StyleSheet.create({
  buttonContainer: {
    position: "absolute",
    bottom: 140,
    left: 0, // You can set this to adjust the horizontal alignment if needed
    right: 0, // You can set this to adjust the horizontal alignment if needed
    alignItems: "center",
    marginBottom: 10, // You can adjust this value to control the spacing from the bottom
  },
  ellipseButton: {
    width: 200,
    height: 50,
    backgroundColor: "#3498db",
    borderRadius: 25,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
  },

  
  loginPosition: {
    left: 0,
    position: "absolute",
  },
  loginScreenChild1Layout: {
    height: 50,
    width: 302,
    borderRadius: Border.br_381xl,
    left: 30,
    position: "absolute",
  },
  rectangleButtonShadowBox: {
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    left: 83,
    position: "absolute",
  },
  loginTypo: {
    textAlign: "right",
    fontSize: FontSize.size_lg,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    color: Color.colorBlack,
    position: "absolute",
  },
  loginScreenChild: {
    width: 91,
    height: 131,
    top: 0,
  },
  loginScreenItem: {
    left: 16,
    width: 162,
    height: 74,
    top: 0,
    position: "absolute",
  },
  loginScreenInner: {
    top: 346,
    width: 128,
    height: 165,
  },
  pngwing5Icon: {
    top: 66,
    left: 110,
    width: 150,
    height: 145,
    position: "absolute",
  },
  welcomeBack: {
    top: 220,
    width: 258,
    height: 41,
    fontFamily: FontFamily.interBold,
    left: 83,
    fontWeight: "700",
    fontSize: FontSize.size_6xl,
    textAlign: "left",
    color: Color.colorBlack,
    position: "absolute",
  },
  rectangleRnptextinput: {
    top: 288,
  },
  loginScreenChild1: {
    top: 378,
  },
  dontHaveAn: {
    fontWeight: "300",
    fontFamily: FontFamily.inriaSerifLight,
    color: Color.colorBlack,
  },
  text: {
    color: "#f5fffa",
  },

  signup: {
    color: Color.colorDarkturquoise_100,
    fontFamily: FontFamily.inriaSerifBold,
    fontWeight: "700",
  },
  dontHaveAnContainer: {
    height: "5.59%",
    width: "66.29%",

    left: "21.17%",
    fontSize: FontSize.size_lg,
    textAlign: "left",
    position: "absolute",
  },

  frame: {
    top: -79,
    left: -187,
    width: 219,
    alignItems: "center",
    justifyContent: "flex-end",
    position: "absolute",
    overflow: "hidden",
  },

  loginScreen: {
    flex: 1,
    width: "100%",
    height: 715,
    backgroundColor: "transparent",
    overflow: "hidden",
  },
});

export default LOGINSCREEN;
