import React, { useState, useEffect } from "react";
import { Text, StyleSheet, View, TouchableOpacity,FlatList,Image } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";
import { firebase } from '../config'; // Replace with the correct path to your firebase.js file


const HistoryScreen = () => {
  const navigation = useNavigation();
  const [chatHistory, setChatHistory] = useState([]);

  useEffect(() => {
    const loadChatHistory = async () => {
      try {
        const user = firebase.auth().currentUser;
  
        if (user) {
          const userMessageRef = firebase.firestore().collection('chatHistory').doc(user.uid);
          const messagesSnapshot = await userMessageRef.collection('messages').orderBy('timestamp').get();
  
          const messages = messagesSnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data(),
          }));
  
          setChatHistory(messages);
        } else {
          console.log('User is not logged in');
          // Handle the case where the user is not logged in
          // You might want to navigate to the login screen or perform some other action
        }
      } catch (error) {
        console.error('Error loading chat history:', error);
      }
    };
  
    loadChatHistory();
  }, []);

  const handleBackPress = () => {
    navigation.navigate("ChatbotScreen");
  };

  const handleLogoutPress = async () => {
    try {
      await firebase.auth().signOut();
      console.log("User signed out");
      // Navigate to the login screen after logout
      navigation.navigate("LOGINSCREEN");
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };
  return (
    <LinearGradient
      style={styles.historyScreen}
      locations={[0, 1]}
      colors={["#3fbaff", "rgba(255, 255, 255, 0)"]}
    >
      <SafeAreaView style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Image
            source={require("../assets/pngegg1.png")}
            style={styles.logo}
            resizeMode="contain"
          />
          <Text style={styles.headerText}>Chat History</Text>
        </View>

        {/* Chat history display */}
        <FlatList
          style={styles.chatHistoryContainer}
          data={chatHistory}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={item.user ? styles.userMessage : styles.botMessage}>
              <Text style={item.user ? styles.userMessageText : styles.botMessageText}>
                {item.user ? 'User:' : 'Bot:'} {item.text}
              </Text>
            </View>
          )}
        />

        {/* Buttons */}
        <View style={styles.buttonContainer}>
          <TouchableOpacity onPress={handleBackPress}>
            <Text style={styles.ellipseButton}>Back</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleLogoutPress}>
            <Text style={styles.ellipseButton}>Logout</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  userMessage: {
    alignSelf: 'flex-end',
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    borderRadius: 10,
    padding: 10,
    marginVertical: 5,
  },
  botMessage: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    borderRadius: 10,
    padding: 10,
    marginVertical: 5,
  },
  userMessageText: {
    color: '#333',
    fontSize: FontSize.size_md,
  },
  botMessageText: {
    color: '#333',
    fontSize: FontSize.size_md,
    fontWeight: 'bold',
  },
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  historyScreen: {
    flex: 1,
    width: "100%",
    justifyContent: "center",
    backgroundColor: "transparent",
    alignItems: "center",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  logo: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  headerText: {
    fontFamily: FontFamily.interBold,
    fontSize: FontSize.size_lg,
    color: "white",
  },
  chatHistoryContainer: {
    flex: 1,
    width: "100%",
    paddingHorizontal: 20,
  },
  messageContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },
  senderName: {
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_md,
    color: "white",
    marginRight: 10,
  },
  messageText: {
    fontFamily: FontFamily.interRegular,
    fontSize: FontSize.size_md,
    color: "white",
  },
  ellipseButton: {
    borderRadius: 100,
    backgroundColor: "skyblue",
    textAlign: "center",
    color: "white",
    paddingVertical: 10,
    paddingHorizontal: 40,
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    width: "100%",
    padding: 20,
  },
});

export default HistoryScreen;
