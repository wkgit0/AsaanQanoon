import React, { useState } from 'react';
import { Text, StyleSheet, View, ImageBackground, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { TextInput as RNPTextInput } from 'react-native-paper';
import { Color, FontSize, FontFamily,Border } from '../GlobalStyles';
import { firebase } from '../config';
import PasswordForm from "../components/PasswordForm";
import MailFormContainer from "../components/MailFormContainer";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";

const ForgotPasswordScreen = ({ navigation, route }) => {
  const { email } = route.params;
  const [otp, setOtp] = useState('');

  const handleResetPassword = async () => {
    try {
      const generatedOtp = '1234'; // Replace with actual OTP generation logic
      const timestamp = new Date().getTime();
  
      await firebase.auth().sendPasswordResetEmail(email, {
        url: `https://fyp-asaan-qanoon.firebaseapp.com/__/auth/action?mode=resetPassword&oobCode=Q7zViCR93CeE1WIExn4CHDKsLgmT13ba0Q0YnGrVo_wAAAGMVItanw&apiKey=AIzaSyCj31SgZyJ5wJG1HCwOU4serlSCZ_zcHy4&lang=en?email=${email}&otp=${generatedOtp}&timestamp=${timestamp}`,
      });
  
      navigation.navigate('LOGINSCREEN', { email, generatedOtp, timestamp });
    } catch (error) {
      console.error('Error sending OTP:', error.message);
    }
  };

  return (
    <LinearGradient
      style={styles.forgotPasswordScreen}
      locations={[0, 1]}
      colors={["rgba(58, 215, 250, 0.66)", "rgba(255, 255, 255, 0)"]}
    >
      <Image
        style={[styles.forgotPasswordScreenChild, styles.forgotPasswordPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Image
        style={styles.forgotPasswordScreenItem}
        contentFit="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <Image
        style={[styles.forgotPasswordScreenInner, styles.forgotPasswordPosition]}
        contentFit="cover"
        source={require("../assets/ellipse-31.png")}
      />
      <ImageBackground
        style={styles.pngwing5Icon}
        resizeMode="cover"
        source={require("../assets/forgot1.png")}
      />
      <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
      <RNPTextInput
        style={[styles.forgotPasswordRnptextinput, styles.forgotPasswordLayout]}
        mode="outlined"
        theme={{ colors: { background: "#fff" } }}
        placeholder="Enter Your mail"
      />
      {/* Reset Password Button */}
      <View style={[styles.buttonContainer, { top: 400 }]}>
        <TouchableOpacity style={styles.ellipseButton} onPress={handleResetPassword}>
          <Text style={styles.buttonText}>Reset Password</Text>
        </TouchableOpacity>
      </View>

      <MailFormContainer emailInputText="enter your mail" />

    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  forgotPasswordPosition: {
    left: 0,
    position: "absolute",
  },
  forgotPasswordScreenChild: {
    width: 91,
    height: 131,
    top: 0,
  },
  forgotPasswordScreenItem: {
    left: 16,
    width: 162,
    height: 74,
    top: 0,
    position: "absolute",
  },
  forgotPasswordScreenInner: {
    top: 346,
    width: 128,
    height: 165,
  },
  pngwing5Icon: {
    top: 66,
    left: 129,
    width: 150,
    height: 145,
    position: "absolute",
  },
  forgotPasswordText: {
    top: 220,
    width: 258,
    height: 41,
    fontFamily: FontFamily.interBold,
    left: 83,
    fontWeight: "700",
    fontSize: FontSize.size_6xl,
    textAlign: "left",
    color: Color.colorBlack,
    position: "absolute",
  },
  forgotPasswordRnptextinput: {
    top: 288,
  },
  forgotPasswordLayout: {
    height: 50,
    width: 302,
    borderRadius: Border.br_381xl,
    left: 30,
    position: "absolute",
  },
  buttonContainer: {
    position: "absolute",
    bottom: 140,
    left: 0,
    right: 0,
    alignItems: "center",
    marginBottom: 10,
  },
  ellipseButton: {
    width: 200,
    height: 50,
    backgroundColor: "#3498db",
    borderRadius: 25,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
  },
  forgotPasswordScreen: {
    flex: 1,
    width: "100%",
    height: 715,
    backgroundColor: "transparent",
    overflow: "hidden",
  },
});

export default ForgotPasswordScreen;