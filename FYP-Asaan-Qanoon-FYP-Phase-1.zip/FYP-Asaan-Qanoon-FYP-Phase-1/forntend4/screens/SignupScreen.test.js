// SignupScreen.test.js
import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import '@testing-library/jest-native/extend-expect';

// Mock the Firebase auth module
jest.mock('@react-native-firebase/auth', () => {
  return {
    __esModule: true,
    default: {
      createUserWithEmailAndPassword: jest.fn(),
    },
  };
});

import SignupScreen from '../screens/SignupScreen';

describe('SignupScreen', () => {
  test('renders without crashing', () => {
    const { getByPlaceholderText, getByText } = render(<SignupScreen />);

    // Ensure that the necessary elements are present
    expect(getByPlaceholderText('Enter your name')).toBeTruthy();
    expect(getByPlaceholderText('Enter your email')).toBeTruthy();
    expect(getByPlaceholderText('Enter your password')).toBeTruthy();
    expect(getByPlaceholderText('Confirm Password')).toBeTruthy();
    expect(getByText('Register')).toBeTruthy();
    expect(getByText('Already have an account? Login')).toBeTruthy();
  });

  test('registers a user when Register button is pressed', async () => {
    const { getByPlaceholderText, getByText } = render(<SignupScreen />);

    // Mock user input
    fireEvent.changeText(getByPlaceholderText('Enter your name'), 'Test User');
    fireEvent.changeText(getByPlaceholderText('Enter your email'), 'test@example.com');
    fireEvent.changeText(getByPlaceholderText('Enter your password'), 'password123');
    fireEvent.changeText(getByPlaceholderText('Confirm Password'), 'password123');

    // Trigger the Register button press
    fireEvent.press(getByText('Register'));

    // Wait for the asynchronous operation to complete
    await waitFor(() => {
      expect(jest.fn().mock.calls.length).toBe(1);  // Add your assertions here
    });
  });

  // Add more test cases as needed
});
