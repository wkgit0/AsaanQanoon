// jest.config.js
module.exports = {
    preset: 'jest-expo',
    setupFilesAfterEnv: ['@testing-library/jest-native/extend-expect'],
    roots: ["<rootDir>"],
    transform: {
      '^.+\\.js$': 'babel-jest',
    },
  };
  