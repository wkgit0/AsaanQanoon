/* fonts */
export const FontFamily = {
  interBold: "Inter-Bold",
  interExtraBold: "Inter-ExtraBold",
  interMedium: "Inter-Medium",
  inriaSerifLight: "InriaSerif-Light",
  interRegular: "Inter-Regular",
  inriaSerifBold: "InriaSerif-Bold",
};

/* font sizes */
export const FontSize = {
  size_lg: 18,
  size_sm: 14,
  size_6xl: 25,
  size_xl: 20,
};
/* Colors */
export const Color = {
  colorBlack: "#000",
  colorGainsboro: "#d9d9d9",
  colorWhite: "#fff",
  colorGray_100: "#101225",
  colorGray: "rgba(0, 0, 0, 0)",
  colorDarkturquoise_100: "#41d6e1",
};
/* Paddings */
export const Padding = {
  p_0: 0,
};
/* border radiuses */
export const Border = {
  br_11xl: 30,
  br_4xs: 9,
  br_31xl: 50,
  br_15xl: 34,
  br_17xl: 36,
  br_3xs: 10,
  br_381xl: 400,
  br_21xl: 40,
  br_381xl: 10,
};
